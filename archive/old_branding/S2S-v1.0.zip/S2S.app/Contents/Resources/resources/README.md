Place third-party installers here for automated setup.

- BlackHole 2ch installer filename: `BlackHole2ch.pkg`
- The app will attempt to install it via `osascript` + `installer` with admin privileges.

If the file is missing, the app falls back to Homebrew or shows the setup guide.
